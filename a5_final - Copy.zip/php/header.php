

<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moon shopping</title>
    
    <!-- adding links-->
    <link rel="stylesheet" type="text/css" href="../css/a5.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">    
    <link rel="stylesheet" href="../css/swiper.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    
    <script defer src="../js/a5.js" async></script>
   <!--
    <script defer src="../js/swiper.min.js"async></script>
    
   -->