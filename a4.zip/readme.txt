My work is done on index-fallback.php , not in my previous website.
Thank you for the sem2 web programming lecture!